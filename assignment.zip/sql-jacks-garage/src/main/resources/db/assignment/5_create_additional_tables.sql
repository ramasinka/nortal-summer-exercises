-- TODO: Should we remove this?
select 'Oh no, an SQL just to keep Liquibase happy. ' ||
       '#hiddenErrors #worksOnMyMachine' from (values(0));

-- 1. Create table WORK_LOG


-- 2. Create table SPARE_PART

